#ifndef __ARM_H
#define __ARM_H   

void arm_init();  //初始化
void CMD_SERVO_MOVE (unsigned int,unsigned char,unsigned int); 
void CMD_ACTION_GROUP_RUN  (unsigned char,unsigned int); 
void CMD_ACTION_GROUP_STOP ();
void CMD_ACTION_GROUP_SPEED (unsigned char,unsigned int);     
#endif

