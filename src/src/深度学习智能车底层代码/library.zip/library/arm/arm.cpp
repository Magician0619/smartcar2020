#include "arm.h"    
#include "arduino.h"

void arm_init()
{
	Serial3.begin(9600);
}  

void CMD_SERVO_MOVE (unsigned int times,unsigned char ID,unsigned int angle) 
{
  unsigned char hexdata[10] = {0x55,0x55,0x08,0x03,0x01,0x00,0x00,0x00,0x00,0x00};
  if(angle<500) angle=500;
  else if (angle>2500) angle = 2500;
  hexdata[5] = (unsigned char)(times%256);
  hexdata[6] = (unsigned char)(times/256);
  hexdata[7] = ID;
  hexdata[8] = (unsigned char)(angle%256);
  hexdata[9] = (unsigned char)(angle/256);
  Serial3.write(hexdata,10);                                                                                      
}

void CMD_ACTION_GROUP_RUN (unsigned char num,unsigned int times)  //执行动作组
{
  unsigned char hexdata[7] = {0x55,0x55,0x05,0x06,0x00,0x00,0x00};   
  hexdata[4] = num;
  hexdata[5] = (unsigned char)(times%256);
  hexdata[6] = (unsigned char)(times/256);
  Serial3.write(hexdata,7);  
}

void CMD_ACTION_GROUP_STOP ()
{
  unsigned char hexdata[4] = {0x55,0x55,0x02,0x07};   
  Serial3.write(hexdata,4);  
}

void CMD_ACTION_GROUP_SPEED (unsigned char num,unsigned int SPEED)
{
  unsigned char hexdata[7] = {0x55,0x55,0x05,0x0B,0x00,0x00,0x00};   
  hexdata[4] = num;
  hexdata[5] = (unsigned char)(SPEED%256);
  hexdata[6] = (unsigned char)(SPEED/256);
  Serial3.write(hexdata,7);
}


