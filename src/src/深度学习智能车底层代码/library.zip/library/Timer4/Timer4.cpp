#include "Timer4.h"

unsigned long Timer4::msecs4;
void (*Timer4::func4)();
volatile unsigned long Timer4::count4;
volatile char Timer4::overflowing4;
volatile unsigned int Timer4::tcnt4;

void Timer4::set(unsigned long us, void (*f)()) {
	float prescaler4 = 0.0;
	
	TIMSK4 &= ~(1<<TOIE4);
	TCCR4A &= ~(1<<WGM41);
	TCCR4A &= ~(1<<WGM40);
	TCCR4B &= ~(1<<WGM42);
	TCCR4B &= ~(1<<WGM43);
	
	TCCR4B &= ~0x07;
	
	if(us<10){
		prescaler4 = 1.0;
		TCCR4B |=0x01;
		tcnt4 =  0xffff - (int)((float)F_CPU * 0.000001);
	}
	else if(us<500){
		prescaler4 = 8.0;
		TCCR4B |=0x02;
		if(us%100 == 0)
		{
			tcnt4 =  0xffff - (int)((float)F_CPU * 0.0001/prescaler4);
			us /=100;
		}
		else if(us%50 == 0)
		{
			tcnt4 =  0xffff - (int)((float)F_CPU * 0.00005/prescaler4);
			us /=50;
		}
		else if(us%20 == 0)
		{
			tcnt4 =  0xffff - (int)((float)F_CPU * 0.00002/prescaler4);
			us /=20;
		}
		else if(us%10 == 0)
		{
			tcnt4 =  0xffff - (int)((float)F_CPU * 0.00001/prescaler4);
			us /=10;
		}
		else
		{
			tcnt4 =  0xffff - (int)((float)F_CPU * 0.000001/prescaler4);
		}
	}
	else if(us<2000){
		prescaler4 = 64.0;
		TCCR4B |=0x03;
		if(us%200 == 0)
		{
			tcnt4 =  0xffff - (int)((float)F_CPU * 0.0002/prescaler4);
			us /=200;
		}
		else if(us%100 == 0)
		{
			tcnt4 =  0xffff - (int)((float)F_CPU * 0.0001/prescaler4);
			us /=100;
		}
		else if(us%50 == 0)
		{
			tcnt4 =  0xffff - (int)((float)F_CPU * 0.00005/prescaler4);
			us /=50;
		}
		else if(us%20 == 0)
		{
			tcnt4 =  0xffff - (int)((float)F_CPU * 0.00002/prescaler4);
			us /=20;
		}
		else
		{
			tcnt4 =  0xffff - (int)((float)F_CPU * 0.00001/prescaler4);
			us /=10;
		}
	}
	else{
		prescaler4 = 256.0;
		TCCR4B |=0x04;
		if(us%4000 == 0)
		{
			tcnt4 =  0xffff - (int)((float)F_CPU * 0.004/prescaler4);
			us /=4000;
		}
		else if(us%2000 == 0)
		{
			tcnt4 =  0xffff - (int)((float)F_CPU * 0.002/prescaler4);
			us /=2000;
		}
		else if(us%1000 == 0)
		{
			tcnt4 =  0xffff - (int)((float)F_CPU * 0.001/prescaler4);
			us /=1000;
		}
		else if(us%500 == 0)
		{
			tcnt4 =  0xffff - (int)((float)F_CPU * 0.0005/prescaler4);
			us /=500;
		}
		else if(us%200 == 0)
		{
			tcnt4 =  0xffff - (int)((float)F_CPU * 0.0002/prescaler4);
			us /=200;
		}
		else
		{
			tcnt4 =  0xffff - (int)((float)F_CPU * 0.0001/prescaler4);
			us /=100;
		}
	}
	
	if (us == 0)
		msecs4 = 1;
	else
		msecs4 = us;
		
	func4 = f;
}

void Timer4::start() {
	count4 = 0;
	overflowing4 = 0;
	TCNT4L = Timer4::tcnt4 & 0xFF;
	TCNT4H = Timer4::tcnt4 >> 8;
	TIMSK4 |= (1<<TOIE4);
}

void Timer4::stop() {
	TIMSK4 &= ~(1<<TOIE4);
}

void Timer4::_overflow() {
	count4++;
	
	if (count4 >= msecs4 && !overflowing4) {
		overflowing4 = 1;
		count4 = 0;
		(*func4)();
		overflowing4 = 0;
	}
}

ISR(TIMER4_OVF_vect) {
	TCNT4L = Timer4::tcnt4 & 0xFF;
	TCNT4H = Timer4::tcnt4 >> 8;
	Timer4::_overflow();
}
