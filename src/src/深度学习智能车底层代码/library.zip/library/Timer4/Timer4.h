#ifndef Timer4_h
#define Timer4_h

#include <avr/interrupt.h>

namespace Timer4 {
	extern unsigned long msecs4;
	extern void (*func4)();
	extern volatile unsigned long count4;
	extern volatile char overflowing4;
	extern volatile unsigned int tcnt4;
	
	void set(unsigned long us, void (*f)());
	void start();
	void stop();
	void _overflow();
}

#endif
