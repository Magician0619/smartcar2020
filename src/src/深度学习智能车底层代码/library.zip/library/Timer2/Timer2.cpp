#include "Timer2.h"

unsigned long Timer2::msecs2;
void (*Timer2::func2)();
volatile unsigned long Timer2::count2;
volatile char Timer2::overflowing2;
volatile unsigned int Timer2::tcnt2;

void Timer2::set(unsigned long us, void (*f)()) {
	float prescaler2 = 0.0;
	
	TIMSK2 &= ~(1<<TOIE2);
	TCCR2A &= ~((1<<WGM21) | (1<<WGM20));
	TCCR2B &= ~(1<<WGM22);
	ASSR &= ~(1<<AS2);
	TIMSK2 &= ~(1<<OCIE2A);
	
	TCCR2B &= ~0x07;
	
	if(us<10){
		prescaler2 = 1.0;
		TCCR2B |=0x01;
		tcnt2 =  256 - (int)((float)F_CPU * 0.000001);
	}
	else if(us<500){
		prescaler2 = 32.0;
		TCCR2B |=0x03;
		if(us%100 == 0)
		{
			tcnt2 =  256 - (int)((float)F_CPU * 0.0001/prescaler2);
			us /=100;
		}
		else if(us%50 == 0)
		{
			tcnt2 =  256 - (int)((float)F_CPU * 0.00005/prescaler2);
			us /=50;
		}
		else if(us%20 == 0)
		{
			tcnt2 =  256 - (int)((float)F_CPU * 0.00002/prescaler2);
			us /=20;
		}
		else if(us%10 == 0)
		{
			tcnt2 =  256 - (int)((float)F_CPU * 0.00001/prescaler2);
			us /=10;
		}
		else
		{
			tcnt2 =  256 - (int)((float)F_CPU * 0.000001/prescaler2);
		}
	}
	else if(us<2000){
		prescaler2 = 128.0;
		TCCR2B |=0x05;
		if(us%200 == 0)
		{
			tcnt2 =  256 - (int)((float)F_CPU * 0.0002/prescaler2);
			us /=200;
		}
		else if(us%100 == 0)
		{
			tcnt2 =  256 - (int)((float)F_CPU * 0.0001/prescaler2);
			us /=100;
		}
		else if(us%50 == 0)
		{
			tcnt2 =  256 - (int)((float)F_CPU * 0.00005/prescaler2);
			us /=50;
		}
		else if(us%20 == 0)
		{
			tcnt2 =  256 - (int)((float)F_CPU * 0.00002/prescaler2);
			us /=20;
		}
		else
		{
			tcnt2 =  256 - (int)((float)F_CPU * 0.00001/prescaler2);
			us /=10;
		}
	}
	else{
		prescaler2 = 256.0;
		TCCR2B |=0x06;
		if(us%4000 == 0)
		{
			tcnt2 =  256 - (int)((float)F_CPU * 0.004/prescaler2);
			us /=4000;
		}
		else if(us%2000 == 0)
		{
			tcnt2 =  256 - (int)((float)F_CPU * 0.002/prescaler2);
			us /=2000;
		}
		else if(us%1000 == 0)
		{
			tcnt2 =  256 - (int)((float)F_CPU * 0.001/prescaler2);
			us /=1000;
		}
		else if(us%500 == 0)
		{
			tcnt2 =  256 - (int)((float)F_CPU * 0.0005/prescaler2);
			us /=500;
		}
		else if(us%200 == 0)
		{
			tcnt2 =  256 - (int)((float)F_CPU * 0.0002/prescaler2);
			us /=200;
		}
		else
		{
			tcnt2 =  256 - (int)((float)F_CPU * 0.0001/prescaler2);
			us /=100;
		}
	}
	
	if (us == 0)
		msecs2 = 1;
	else
		msecs2 = us;
		
	func2 = f;
}

void Timer2::start() {
	count2 = 0;
	overflowing2 = 0;
	TCNT2 = tcnt2;
	TIMSK2 |= (1<<TOIE2);
}

void Timer2::stop() {
	TIMSK2 &= ~(1<<TOIE2);
}

void Timer2::_overflow() {
	count2++;
	
	if (count2 >= msecs2 && !overflowing2) {
		overflowing2 = 1;
		count2 = 0;
		(*func2)();
		overflowing2 = 0;
	}
}

ISR(TIMER2_OVF_vect) {
	TCNT2 = Timer2::tcnt2;
	Timer2::_overflow();
}
