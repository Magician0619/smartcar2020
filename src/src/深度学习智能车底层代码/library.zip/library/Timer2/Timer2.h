#ifndef Timer2_h
#define Timer2_h

#include <avr/interrupt.h>

namespace Timer2 {
	extern unsigned long msecs2;
	extern void (*func2)();
	extern volatile unsigned long count2;
	extern volatile char overflowing2;
	extern volatile unsigned int tcnt2;
	
	void set(unsigned long us, void (*f)());
	void start();
	void stop();
	void _overflow();
}

#endif
