#ifndef Timer5_h
#define Timer5_h

#include <avr/interrupt.h>

namespace Timer5 {
	extern unsigned long msecs5;
	extern void (*func5)();
	extern volatile unsigned long count5;
	extern volatile char overflowing5;
	extern volatile unsigned int tcnt5;
	
	void set(unsigned long us, void (*f)());
	void start();
	void stop();
	void _overflow();
}

#endif
