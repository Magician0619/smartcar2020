#include "Timer5.h"

unsigned long Timer5::msecs5;
void (*Timer5::func5)();
volatile unsigned long Timer5::count5;
volatile char Timer5::overflowing5;
volatile unsigned int Timer5::tcnt5;

void Timer5::set(unsigned long us, void (*f)()) {
	float prescaler5 = 0.0;
	
	TIMSK5 &= ~(1<<TOIE5);
	TCCR5A &= ~(1<<WGM51);
	TCCR5A &= ~(1<<WGM50);
	TCCR5B &= ~(1<<WGM52);
	TCCR5B &= ~(1<<WGM53);
	
	TCCR5B &= ~0x07;
	
	if(us<10){
		prescaler5 = 1.0;
		TCCR5B |=0x01;
		tcnt5 =  0xffff - (int)((float)F_CPU * 0.000001);
	}
	else if(us<500){
		prescaler5 = 8.0;
		TCCR5B |=0x02;
		if(us%100 == 0)
		{
			tcnt5 =  0xffff - (int)((float)F_CPU * 0.0001/prescaler5);
			us /=100;
		}
		else if(us%50 == 0)
		{
			tcnt5 =  0xffff - (int)((float)F_CPU * 0.00005/prescaler5);
			us /=50;
		}
		else if(us%20 == 0)
		{
			tcnt5 =  0xffff - (int)((float)F_CPU * 0.00002/prescaler5);
			us /=20;
		}
		else if(us%10 == 0)
		{
			tcnt5 =  0xffff - (int)((float)F_CPU * 0.00001/prescaler5);
			us /=10;
		}
		else
		{
			tcnt5 =  0xffff - (int)((float)F_CPU * 0.000001/prescaler5);
		}
	}
	else if(us<2000){
		prescaler5 = 64.0;
		TCCR5B |=0x03;
		if(us%200 == 0)
		{
			tcnt5 =  0xffff - (int)((float)F_CPU * 0.0002/prescaler5);
			us /=200;
		}
		else if(us%100 == 0)
		{
			tcnt5 =  0xffff - (int)((float)F_CPU * 0.0001/prescaler5);
			us /=100;
		}
		else if(us%50 == 0)
		{
			tcnt5 =  0xffff - (int)((float)F_CPU * 0.00005/prescaler5);
			us /=50;
		}
		else if(us%20 == 0)
		{
			tcnt5 =  0xffff - (int)((float)F_CPU * 0.00002/prescaler5);
			us /=20;
		}
		else
		{
			tcnt5 =  0xffff - (int)((float)F_CPU * 0.00001/prescaler5);
			us /=10;
		}
	}
	else{
		prescaler5 = 256.0;
		TCCR5B |=0x04;
		if(us%4000 == 0)
		{
			tcnt5 =  0xffff - (int)((float)F_CPU * 0.004/prescaler5);
			us /=4000;
		}
		else if(us%2000 == 0)
		{
			tcnt5 =  0xffff - (int)((float)F_CPU * 0.002/prescaler5);
			us /=2000;
		}
		else if(us%1000 == 0)
		{
			tcnt5 =  0xffff - (int)((float)F_CPU * 0.001/prescaler5);
			us /=1000;
		}
		else if(us%500 == 0)
		{
			tcnt5 =  0xffff - (int)((float)F_CPU * 0.0005/prescaler5);
			us /=500;
		}
		else if(us%200 == 0)
		{
			tcnt5 =  0xffff - (int)((float)F_CPU * 0.0002/prescaler5);
			us /=200;
		}
		else
		{
			tcnt5 =  0xffff - (int)((float)F_CPU * 0.0001/prescaler5);
			us /=100;
		}
	}
	
	if (us == 0)
		msecs5 = 1;
	else
		msecs5 = us;
		
	func5 = f;
}

void Timer5::start() {
	count5 = 0;
	overflowing5 = 0;
	TCNT5L = Timer5::tcnt5 & 0xFF;
	TCNT5H = Timer5::tcnt5 >> 8;
	TIMSK5 |= (1<<TOIE5);
}

void Timer5::stop() {
	TIMSK5 &= ~(1<<TOIE5);
}

void Timer5::_overflow() {
	count5++;
	
	if (count5 >= msecs5 && !overflowing5) {
		overflowing5 = 1;
		count5 = 0;
		(*func5)();
		overflowing5 = 0;
	}
}

ISR(TIMER5_OVF_vect) {
	TCNT5L = Timer5::tcnt5 & 0xFF;
	TCNT5H = Timer5::tcnt5 >> 8;
	Timer5::_overflow();
}
