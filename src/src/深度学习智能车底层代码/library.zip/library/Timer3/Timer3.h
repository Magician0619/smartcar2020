#ifndef Timer3_h
#define Timer3_h

#include <avr/interrupt.h>

namespace Timer3 {
	extern unsigned long msecs3;
	extern void (*func3)();
	extern volatile unsigned long count3;
	extern volatile char overflowing3;
	extern volatile unsigned int tcnt3;
	
	void set(unsigned long us, void (*f)());
	void start();
	void stop();
	void _overflow();
}

#endif
