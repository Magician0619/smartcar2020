#include "Timer3.h"

unsigned long Timer3::msecs3;
void (*Timer3::func3)();
volatile unsigned long Timer3::count3;
volatile char Timer3::overflowing3;
volatile unsigned int Timer3::tcnt3;

void Timer3::set(unsigned long us, void (*f)()) {
	float prescaler3 = 0.0;
	
	TIMSK3 &= ~(1<<TOIE3);
	TCCR3A &= ~(1<<WGM31);
	TCCR3A &= ~(1<<WGM30);
	TCCR3B &= ~(1<<WGM32);
	TCCR3B &= ~(1<<WGM33);
	
	TCCR3B &= ~0x07;
	
	if(us<10){
		prescaler3 = 1.0;
		TCCR3B |=0x01;
		tcnt3 =  0xffff - (int)((float)F_CPU * 0.000001);
	}
	else if(us<500){
		prescaler3 = 8.0;
		TCCR3B |=0x02;
		if(us%100 == 0)
		{
			tcnt3 =  0xffff - (int)((float)F_CPU * 0.0001/prescaler3);
			us /=100;
		}
		else if(us%50 == 0)
		{
			tcnt3 =  0xffff - (int)((float)F_CPU * 0.00005/prescaler3);
			us /=50;
		}
		else if(us%20 == 0)
		{
			tcnt3 =  0xffff - (int)((float)F_CPU * 0.00002/prescaler3);
			us /=20;
		}
		else if(us%10 == 0)
		{
			tcnt3 =  0xffff - (int)((float)F_CPU * 0.00001/prescaler3);
			us /=10;
		}
		else
		{
			tcnt3 =  0xffff - (int)((float)F_CPU * 0.000001/prescaler3);
		}
	}
	else if(us<2000){
		prescaler3 = 64.0;
		TCCR3B |=0x03;
		if(us%200 == 0)
		{
			tcnt3 =  0xffff - (int)((float)F_CPU * 0.0002/prescaler3);
			us /=200;
		}
		else if(us%100 == 0)
		{
			tcnt3 =  0xffff - (int)((float)F_CPU * 0.0001/prescaler3);
			us /=100;
		}
		else if(us%50 == 0)
		{
			tcnt3 =  0xffff - (int)((float)F_CPU * 0.00005/prescaler3);
			us /=50;
		}
		else if(us%20 == 0)
		{
			tcnt3 =  0xffff - (int)((float)F_CPU * 0.00002/prescaler3);
			us /=20;
		}
		else
		{
			tcnt3 =  0xffff - (int)((float)F_CPU * 0.00001/prescaler3);
			us /=10;
		}
	}
	else{
		prescaler3 = 256.0;
		TCCR3B |=0x04;
		if(us%4000 == 0)
		{
			tcnt3 =  0xffff - (int)((float)F_CPU * 0.004/prescaler3);
			us /=4000;
		}
		else if(us%2000 == 0)
		{
			tcnt3 =  0xffff - (int)((float)F_CPU * 0.002/prescaler3);
			us /=2000;
		}
		else if(us%1000 == 0)
		{
			tcnt3 =  0xffff - (int)((float)F_CPU * 0.001/prescaler3);
			us /=1000;
		}
		else if(us%500 == 0)
		{
			tcnt3 =  0xffff - (int)((float)F_CPU * 0.0005/prescaler3);
			us /=500;
		}
		else if(us%200 == 0)
		{
			tcnt3 =  0xffff - (int)((float)F_CPU * 0.0002/prescaler3);
			us /=200;
		}
		else
		{
			tcnt3 =  0xffff - (int)((float)F_CPU * 0.0001/prescaler3);
			us /=100;
		}
	}
	
	if (us == 0)
		msecs3 = 1;
	else
		msecs3 = us;
		
	func3 = f;
}

void Timer3::start() {
	count3 = 0;
	overflowing3 = 0;
	TCNT3L = Timer3::tcnt3 & 0xFF;
	TCNT3H = Timer3::tcnt3 >> 8;
	TIMSK3 |= (1<<TOIE3);
}

void Timer3::stop() {
	TIMSK3 &= ~(1<<TOIE3);
}

void Timer3::_overflow() {
	count3++;
	
	if (count3 >= msecs3 && !overflowing3) {
		overflowing3 = 1;
		count3 = 0;
		(*func3)();
		overflowing3 = 0;
	}
}

ISR(TIMER3_OVF_vect) {
	TCNT3L = Timer3::tcnt3 & 0xFF;
	TCNT3H = Timer3::tcnt3 >> 8;
	Timer3::_overflow();
}
